sap.ui.controller("ZSKILL_MATRIX_TOOL.ext.controller.ObjectPageExt", {

	onClickActionZSKILLMATRIX_C_USERSSections1: function (oEvent) {},
	onClickActionZSKILLMATRIX_C_USERSSections2: function (oEvent) {},
	onClickActionZSKILLMATRIX_C_USERSSections1: function (oEvent) {},
	onClickActionZSKILLMATRIX_C_USERSSections2: function (oEvent) {},
	onClickActionZSKILLMATRIX_C_USERSSections1: function (oEvent) {},
	onClickActionZSKILLMATRIX_C_USERSSections2: function (oEvent) {}
});